let admin = {};
admin["__proto__"].isAdmin = false;

console.log(admin.isAdmin);