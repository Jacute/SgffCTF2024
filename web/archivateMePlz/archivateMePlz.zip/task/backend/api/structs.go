package api

type Archive struct {
	Name string `json:"file"`
}
